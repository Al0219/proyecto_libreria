/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CRUDs;

import POJOs.Compras;
import POJOs.DetalleCompra;
import POJOs.Productos;
import POJOs.Proveedores;
import POJOs.Usuarios;
import java.util.Date;
import java.util.List;
import java.util.Set;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author 20041
 */
public class CRUDDetalleCompra {
    public static List<DetalleCompra>universo(){
        Session session = HibernateUtil.HibernateUtil.getSessionFactory().openSession();
        List<DetalleCompra> lista=null;
        try{
            session.beginTransaction();
            Criteria criteria = session.createCriteria(DetalleCompra.class);
            criteria.add(Restrictions.eq("estadoCompra",true));
            criteria.setProjection(Projections.projectionList()
                    .add(Projections.property("numeroCompra"))
            .add(Projections.property("proveedores"))
            .add(Projections.property("usuarios"))
            .add(Projections.property("fechaCompra"))
            );
            criteria.addOrder(Order.desc("numeroCompra"));
            lista = criteria.list();
        }catch(Exception e){
            System.out.println("error: "+e);
        }finally{
            session.getTransaction().commit();
        }
        return lista;
    }

    public static boolean crear(int numeroDocumento, Compras compras, Productos productos, 
            float cantidad, float precioUnitario, float totalCompra){
        boolean flag = false;
        Session session = HibernateUtil.HibernateUtil.getSessionFactory().openSession();
        Criteria criteria = session.createCriteria(DetalleCompra.class);
       
        DetalleCompra insert = (DetalleCompra)criteria.uniqueResult();
        Transaction transaction=null;
        try{
           transaction = session.beginTransaction();
           if(insert ==null){
               insert=new DetalleCompra();
               
               insert.setNumeroDocumento(numeroDocumento);
               insert.setCompras(compras);
               insert.setProductos(productos);
               insert.setCantidad(cantidad);
               insert.setPrecioUnitario(precioUnitario);
               insert.setTotalCompra(totalCompra);
               session.save(insert);
               flag=true;
           }
            transaction.commit();
        }catch(Exception e){
            transaction.rollback();
        }finally{
            session.close();
        }
        return flag;
    }
    
    public static boolean actualizar(int numeroDocumento, Compras compras, Productos productos, 
            float cantidad, float precioUnitario, float totalCompra){
        boolean flag = false;
        Session session = HibernateUtil.HibernateUtil.getSessionFactory().openSession();
        Criteria criteria = session.createCriteria(DetalleCompra.class);
        criteria.add(Restrictions.eq("numeroDocumento", numeroDocumento));
        DetalleCompra insert = (DetalleCompra)criteria.uniqueResult();
        Transaction transaction=null;
        try{
           transaction = session.beginTransaction();
           if(insert != null){
               insert.setNumeroDocumento(numeroDocumento);
               insert.setCompras(compras);
               insert.setProductos(productos);
               insert.setCantidad(cantidad);
               insert.setPrecioUnitario(precioUnitario);
               insert.setTotalCompra(totalCompra);
               session.update(insert);
               flag=true;
           }
            transaction.commit();
        }catch(Exception e){
            transaction.rollback();
        }finally{
            session.close();
        }
        return flag;
    }
    
    public static boolean anular(int numeroDocumento, Compras compras, Productos productos, 
            float cantidad, float precioUnitario, float totalCompra){
        boolean flag = false;
        Session session = HibernateUtil.HibernateUtil.getSessionFactory().openSession();
        Criteria criteria = session.createCriteria(DetalleCompra.class);
        criteria.add(Restrictions.eq("numeroDocumento", numeroDocumento));
        DetalleCompra anular = (DetalleCompra)criteria.uniqueResult();
        Transaction transaction=null;
        try{
           transaction = session.beginTransaction();
           if(anular != null){
               anular.setEstadoCompra(false); // no se que hacer aqui :(
               session.update(anular);
               flag=true;
           }
            transaction.commit();
        }catch(Exception e){
            transaction.rollback();
        }finally{
            session.close();
        }
        return flag;
    }
    
}
